﻿using System;

namespace radhikatest
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            for(int i=1;  i <= 100; i++)
            {
                if (i > 3 && i % 3 == 0 && i > 5 && i % 5 == 0)
                {
                    Console.WriteLine(i+" is - fizzbuzz");
                }
               else if (i > 3 && i%3==0)
                {
                    Console.WriteLine(i + " is - fizz");
                }
                else if(i>5 && i % 5 == 0)
                {
                    Console.WriteLine(i + " is - buzz");
                }
            }
            Console.WriteLine("abcdef reversed is - "+ reverse("abcdef"));
            Console.ReadKey();
        }

      private static string reverse(string val)
        {
            string revString = "";
            for(int i= val.Length-1; i>=0; i--)
            {
                revString = revString+val[i];
            }

            return revString;
        }
    }
}
