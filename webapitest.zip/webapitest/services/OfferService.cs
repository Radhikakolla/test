﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using webapitest.models;

namespace webapitest.services
{
    public class OfferService : IOfferService
    {
        private List<Product> Inventory { get; set; }

        private void setProducts()
        {
            this.Inventory = new List<Product>() {
                new Product("P1", 1000, "P1 desc"),
                new Product("P2", 200, "P2 desc"),
                new Product("P3", 400, "P3 desc"),
                new Product("P4", 700, "P4 desc"),
                new Product("P5", 600, "P5 desc"),
                new Product("P6", 800, "P6 desc")
            };
        }
        public OfferService()
        { 
            this.setProducts();
        }
        public List<Product> GetAllProducts()
        {
            return this.Inventory;
        }
        public void AddProduct(Product p)
        {
            this.Inventory.Add(p);

        }
        public List<Offer> GetTodaysOffers()
        {
            List<Offer> offers = new List<Offer>();
            List<Product> products;
            for (int i = 1; i <= 4; i++)
            {
                products = new List<Product>(){
                new Product("random"+i, 1000, "random"+i+"desc"),
                new Product("random"+i+1, 200, "random"+i+1+"desc"),
                new Product("random"+i+2, 400, "random"+i+2+"desc") };

                Offer offer = new Offer("ComboPackage" + i, products);
                offers.Add(offer);
            }
            return offers;
        }
    }
}
