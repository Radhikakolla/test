﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using webapitest.models;

namespace webapitest.services
{
    interface IOfferService
    {
        List<Product> GetAllProducts();
        void AddProduct(Product p);
        List<Offer> GetTodaysOffers();
    }
}
