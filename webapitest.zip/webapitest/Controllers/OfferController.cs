﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using webapitest.models;
using webapitest.services;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace webapitest.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OfferController : ControllerBase
    {
        private readonly OfferService _offerService;

        public OfferController(OfferService offerService)
        {
            this._offerService = offerService;
        }
        // GET: api/<OfferController>
        [HttpGet]
        [Route("gettodaysoffers")]
        public List<Offer> GetTodaysOffers()
        {
            return _offerService.GetTodaysOffers();
        }
        [HttpGet]
        [Route("getproductsbylowestthree")]
        public List<Product> GetProductsByLowestThree()
        {
            IEnumerable<Product> products = _offerService.GetAllProducts();
            return products.OrderByDescending(p => p.Price).Take(3).ToList();
        }

        [HttpGet]
        [Route("getsecondlowesetproduct")]
        public Product GetSecondLowestProduct()
        {
            IEnumerable<Product> products = _offerService.GetAllProducts();
          return products.OrderByDescending(p => p.Price).Skip(1).FirstOrDefault();
        }

        // POST api/<OfferController>
        [HttpPost]
        public void Post([FromBody] Product product )
        {
            this._offerService.AddProduct(product);

        }
    }
}
