﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace webapitest.models
{
    /// <summary>
    /// product class gives product object
    /// </summary>
    public class Product
    {
        /// <summary>
        /// ProductName 
        /// </summary>
        public string ProductName { get; set; }
        /// <summary>
        /// Price
        /// </summary>
        public decimal Price { get; set; }

        /// <summary>
        /// Description
        /// </summary>
        public string Description { get; set; }


        public Product(string productName, decimal price, string description)
        {
            this.ProductName = productName;
            this.Price = price;
            this.Description = description;

        }
    }
}
