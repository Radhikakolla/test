﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace webapitest.models
{
    /// <summary>
    /// Offer class give offer object with name list of products
    /// </summary>
    public class Offer
    {
        /// <summary>
        /// OfferName
        /// </summary>
       public string OfferName { get; set; }

        /// <summary>
        /// list of products
        /// </summary>
        public List<Product> Products { get; set; }
        public Offer(string offerName, List<Product> products )
        {
            this.OfferName = offerName;
            this.Products = products;
        }
    }
}
